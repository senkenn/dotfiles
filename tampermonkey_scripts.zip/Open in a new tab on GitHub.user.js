// ==UserScript==
// @name         Open in a new tab on GitHub
// @namespace
// @version      0.1
// @description
// @author       You
// @match        https://github.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const links = document.getElementsByTagName('a')
    Array.prototype.forEach.call(links, link => {
        const isExternalLink =
              link.href.match(/^https?:\/\/.+/) && !link.href.includes('github.com')
        if (isExternalLink) {
            link.target = '_blank'
            link.rel = [link.rel, 'noopener', 'noreferrer'].join(' ')
        }
    })
})();